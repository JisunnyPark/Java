package kr.co.bitcamp.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import common.util.JDBC_Close;

public class Login_DAO {

    
    private final String DRIVER = "oracle.jdbc.OracleDriver"; 
    private final String URL = "jdbc:oracle:thin:@localhost:1521:xe"; 
    private final String USER = "mystudy";
    private final String PASSWORD = "mystudypw"; 
    
    private Connection conn;   
    private PreparedStatement prestmt;
    private ResultSet rs;
    Scanner sc = new Scanner(System.in);
    
    public Login_DAO() {
       try {
          Class.forName(DRIVER);
       } catch (ClassNotFoundException e) {
          e.printStackTrace();
       }
    }
    
  //회원가입--------------------------------------------------------
    public int insertCreateMember(Login_VO CreateMembers) {
         int result = 0;
         
         Connection conn = null;
         PreparedStatement prestmt = null;
         
         try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

            StringBuilder sb = new StringBuilder();
            
            sb.append("INSERT INTO BOOK_MEMBER ");
            sb.append("       (ID, PW, NAME, PHONE, ADDRESS) ");
            sb.append("VALUES (?, ?, ?, ?, ?) ");
            
            prestmt = conn.prepareStatement(sb.toString());
            
            int i = 1;
       
            prestmt.setString(i++, CreateMembers.getId());
            prestmt.setString(i++, CreateMembers.getPw());
            prestmt.setString(i++, CreateMembers.getName());
            prestmt.setString(i++, CreateMembers.getPhone());
            prestmt.setString(i++, CreateMembers.getAddress());
            
     
            result = prestmt.executeUpdate();
   
          } catch (SQLException e) {
        	  
             e.printStackTrace();
             
          } finally {
        	  
             JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
             
          }
         
         return result;
      }
    
    //로그인--------------------------------------------------------------------
    public int loginTest(String id, String password) {
        boolean flag = false;
        String sql = "";
 
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

            sql = "SELECT PW FROM BOOK_MEMBER WHERE ID= ?";             
 
            prestmt = conn.prepareStatement(sql);

            prestmt.setString(1, id);

            rs = prestmt.executeQuery();
            
            if (rs.next()) {
            	
                if (rs.getString(1).equals(password)) 
                    return 1; // 로그인 성공
                
                else 
                	
                    return 0; // 비밀번호 불일치
                
            }
            return -1; // 아이디가 없음
                
        } catch (Exception e) {
        	
            e.printStackTrace();
        }
        
        return -2; // DB 오류 
    }
    
    
}
