package kr.co.bitcamp.project;

import java.sql.Date;

public class MSG_VO {

	private String requestId;
	private String bookId;
	private String content;
	private Date redate;

	public MSG_VO(String requestId, String bookId, String content) {
		super();
		this.requestId = requestId;
		this.bookId = bookId;
		this.content = content;
	}
		
	public MSG_VO(String requestId, String bookId, String content, Date redate) {
		super();
		this.requestId = requestId;
		this.bookId = bookId;
		this.content = content;
		this.redate = redate;
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getRedate() {
		return redate;
	}

	public void setRedate(Date redate) {
		this.redate = redate;
	}

	@Override
	public String toString() {
		return "책 번호: " + bookId
		        + "\n 구매자ID :" + requestId
		        + "\n 메세지 내용 :" + content
		        + "\n 날짜 : " + redate +"\n";
	}
	
	
	
	
	
}
