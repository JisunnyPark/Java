package kr.co.bitcamp.project;

import java.util.Scanner;

public class Menu {
	
	static Scanner scan = new Scanner(System.in);
	static int userChoice;
	private static int loginNum;
	
	    //---------------------------------------------------------------------------------------->
	    //메인 시작
        public static void main(String[] args) {
         
        	Login_DAO ldao = new Login_DAO();
            Login_Print pr = new Login_Print();
            
            do{
                
            System.out.println(" ───────────────────────   >>>> [ IT BOOK ] <<<<  ──────────────────── ");
            System.out.println("                                                                       ");
            System.out.println("                             내가 찾던 바로 그 책 !                          ");
            System.out.println("                          IT도서 중고 거래 플랫폼 잇북                        ");
            System.out.println("                                                                        ");
            System.out.println("                                             ☑ 로그인 후 이용하실 수 있습니다. ");
            System.out.println(" ===================================================================== ");
            System.out.println("         1. 회원가입       |       2. 로그인       |        3. 종료          ");
            System.out.println(" ───────────────────────────────────────────────────────────────────── ");
            System.out.print("▶ 메뉴를 선택해주세요: "); 
            loginNum = scan.nextInt();
            
            switch(loginNum) {
            
            case 1 :
                pr.CreateMembers();     //회원가입
                break;
                
            case 2 :
                pr.LoginMembers();      //로그인
                break;
                
            case 3 :
                System.out.println("");
                System.out.println(">> IT BOOK 중고 거래 플랫폼을 이용해주셔서 감사합니다. <<");       //종료
                System.exit(loginNum);
                break;
            
            default:
                System.out.println("※ 메뉴에 없는 번호를 선택하셨습니다. \n");
                break;
            }
            
        } while (!"2".equals(loginNum));
                           
    }
        
      //---------------------------------------------------------------------------------------->
      //1.카테고리 메서드
    static void showMenu() {
        
        System.out.println("");
        System.out.println(" ─────────────────────────────────>>> 카테고리 <<<──────────────────────────── ");
        System.out.println(" ========================================================================== ");
        System.out.println("   1. 상품등록   |   2. 상품관리   │   3. 도서목록   |   4. 커뮤니티   |    5. 종료     ");
        System.out.println(" ────────────────────────────────────────────────────────────────────────── ");
        System.out.print("▶ 메뉴를 선택해주세요: ");
        userChoice = scan.nextInt();                
        
        while(true) {
            
            switch(userChoice) {
            
            case 1 : 
                  Manage_Print upload = new Manage_Print();     //상품등록
                  upload.uploadBook();
                break;
                
            case 2 :
                showmenu2();        //상품관리
                break;
                
            case 3 : 
                showmenu3();        //도서목록
                
            case 4 :
            	showmenu5();       
                
            case 5 :
            	System.out.println("");
            	System.out.println(">> IT BOOK 중고 거래 플랫폼을 이용해주셔서 감사합니다. <<");
            	System.exit(0);
            }
       }    
  }
        //---------------------------------------------------------------------------------------->
        //2.도서 관리 메서드
    	public static void showmenu2() {
           
    		while(true) {
                
                System.out.println("");
                System.out.println(" ────────────────────────────────>>> 나의 도서 관리 <<<────────────────────────────── ");
                System.out.println(" ================================================================================ ");
                System.out.println("     1. 나의 판매 목록   |   2. 상품수정   │   3. 상품삭제   |   4. 쪽지함   |   5. 뒤로가기   ");
                System.out.println(" ──────────────────────────────────────────────────────────────────────────────── ");
                System.out.print("▶ 메뉴를 선택해주세요: ");
                userChoice = scan.nextInt();
                
                 switch(userChoice) {
                 case 1 :
                     Manage_Print myList = new Manage_Print();
                     myList.manageBook();
                     break;
                     
                 case 2 :
                	 Manage_Print updateBook = new Manage_Print();
                     updateBook.modifyBook();
                     break;
                     
                 case 3 :
                	 Manage_Print delBook = new Manage_Print();
                     delBook.deleteBook();
                     break;
                     
                 case 4 :
                	 Manage_Print chkMsg = new Manage_Print();
                	 chkMsg.checkMsg();
                     break;
                     
                 case 5 :
                     showMenu();
                     break;
                 
                 }
            }
        }
    	
    	//---------------------------------------------------------------------------------------->
        //3. 도서 목록 및 검색 메서드
        public static void showmenu3() {//===================================================================> 3번 메서드
          
        	while(true) {
                
                System.out.println("");
                System.out.println(" ───────────────────────────>>> 도서 목록 및 검색 <<<───────────────────────── ");
                System.out.println(" ========================================================================= ");
                System.out.println("   1. 도서 전체 목록   |   2. 카테고리별 목록   │   3. 도서 검색    |    4. 뒤로가기    ");
                System.out.println(" ───────────────────────────────────────────────────────────────────────── ");
                System.out.print("▶ 메뉴를 선택해주세요: ");
                userChoice = scan.nextInt();
                    
                 switch(userChoice) {
                 case 1 :
                     
                     List_Print lstAll = new List_Print();
                     lstAll.listAll();
                     break;
                     
                 case 2 :
                     showmenu4();
                     break;
                         
                 case 3 :
                     List_Print sb = new List_Print();
                     sb.search();
                     break;
                     
                 case 4 :
                     showmenu2();
                     break;
                     
                 }
            }
        }
            
        //---------------------------------------------------------------------------------------->
        //4. 도서별 카테고리 목록 메서드
        public static void showmenu4() {
           
        	while(true) {
                
                System.out.println("");
                System.out.println(" ─────────────────────────────>>> 도서별 카테고리 <<<──────────────────────── ");
                System.out.println(" ======================================================================== ");
                System.out.println("  1. 프로그래밍   |   2. DB   │   3. 수험서    |   4. 기타 도서   |   5. 뒤로가기   ");
                System.out.println(" ──────────────────────────────────────────────────────────────────────── ");
                System.out.print("▶ 원하는 도서 목록 카테고리를 선택해주세요: ");
                userChoice = scan.nextInt();
                        
                     switch(userChoice) {
                     case 1 :
                         List_Print lstProgram = new List_Print();
                         lstProgram.listProgram();
                         break;
                         
                     case 2 :
                         List_Print lstDB = new List_Print();
                         lstDB.listDB();
                         break;
                         
                     case 3 :
                         List_Print lstCerti = new List_Print();
                         lstCerti.listCerti();
                         break;
                         
                     case 4 :
                         List_Print lstOther = new List_Print();
                         lstOther.listOther();
                         break;
                         
                     case 5 :
                         showmenu3();
                         break;
                         
                     }                
            }            
    }
        
        //---------------------------------------------------------------------------------------->
        //5. 커뮤니티 게시판 메서드
        public static void showmenu5() {
           
        	while(true) {
                
                System.out.println("");
                System.out.println(" ────────────────────────────>>> 커뮤니티 게시판 <<<──────────────────────── ");
                System.out.println(" ======================================================================= ");
                System.out.println("   1. 게시글 등록    |     2. 게시글 목록    |    3. 뒤로가기     |   4. 종료       ");
                System.out.println(" ─────────────────────────────────────────────────────────────────────── ");
                System.out.print("▶ 메뉴를 선택해주세요: ");
                userChoice = scan.nextInt();
                System.out.println("");
                        
                     switch(userChoice) {
                     case 1 :
                         Board_Print upPost = new Board_Print();
                         upPost.uploadPost();
                         break;
                         
                     case 2 :
                    	 Board_Print pstList = new Board_Print();
                    	 pstList.boardList();
                         break;
                         
                     case 3 :
                         showMenu();
                         break;
                         
                     case 4 :
                    	 System.out.println("");
                    	 System.out.println(">> IT BOOK 중고 거래 플랫폼을 이용해주셔서 감사합니다. <<");
                         System.exit(0);
                      
                     }                
              }            
      }
}

