package kr.co.bitcamp.project;

import java.util.List;
import java.util.Scanner;

public class List_Print {
	
	static Scanner scan = new Scanner(System.in);
    Login_Print print = new Login_Print();
    
    List_DAO mylst;	
    List_DAO select;
	List_DAO message;
	static String bookName;
	
	public List_Print() {
		
		mylst = new List_DAO();		
		message = new List_DAO();
		select = new List_DAO();
		
	}		

	//---------------------------------------------------------------------------------------->
    //도서 전체 목록 확인
	public void listAll() {
		
	    System.out.println("");
	    System.out.println(" ========== [ 전체 도서 목록 ] ==========");
	        List<List_VO> listall =  mylst.listAll();
	        
	        for (List_VO mvo : listall) {
	            System.out.println(mvo);
	        }
	        
	        System.out.println(">> 구매를 원하시는 도서가 있으면 [1] 없으면 [2] 번을 눌러주세요.");
	        int type = scan.nextInt();
	        
	        if(type == 1) {
	        	sendMsg();
	        } else {
	        	
	        	Menu.showMenu();
	        	
	        }
	        
	}
	
	//---------------------------------------------------------------------------------------->
    //도서별 전체 목록 (프로그래밍)
	public void listProgram() {
	    
	    System.out.println("");
	    System.out.println(" ========== [ 프로그래밍 ] ==========");
		 List<List_VO> programing = mylst.lstProgram();
		 
		 for (List_VO lst : programing) {
			 System.out.println(lst);
		 }
	}
		
	//---------------------------------------------------------------------------------------->
    //도서별 전체 목록 (데이터베이스)
	public void listDB() {
	    
	    System.out.println("");
	    System.out.println(" ========== [ 데이터베이스 ] ==========");
		 List<List_VO> db = mylst.lstDB();
		 
		 for (List_VO lst : db) {
			 System.out.println(lst);
		 }
	}
	
	
	//---------------------------------------------------------------------------------------->
    //도서별 전체 목록 (수험서)
	public void listCerti() {
		
	    System.out.println(" ========== [ 수험서 ] ==========");
		 List<List_VO> certi = mylst.lstCerti();
		 
		 for (List_VO lst : certi) {
			 
			 System.out.println(lst);
			 
		 }
		 
	}
	
	
	//---------------------------------------------------------------------------------------->
    //도서별 전체 목록 (기타)
	public void listOther() {
		
	    System.out.println("");
	    System.out.println(" ========== [ 기타 ] ==========");
		 List<List_VO> etc = mylst.lstEtc();
		 
		 for (List_VO lst : etc) {
			 
			 System.out.println(lst);
			 
		 }
	}
	
	
	//---------------------------------------------------------------------------------------->
    //도서 검색
	public void search() {
		
	       System.out.println("");
	       System.out.println(">>> 찾으시는 도서를 검색해주세요.");
	       System.out.print("책 이름 : ");
	       bookName = scan.next();
	       System.out.println("");
	        
	       while(true) {
	    	   
		   	    System.out.println("");
			    System.out.println(" ========== [ 검색 도서 목록 ] ==========");
				 List<List_VO> bookSearch = mylst.search();
				 
				 for (List_VO lst : bookSearch) {
					 
					 System.out.println(lst);
					 
				 }
	           
	            System.out.println("");
	            System.out.println(">> 구매를 원하시는 도서가 있으면 [1] 없으면 [2] 번을 눌러주세요.");
	            int type = scan.nextInt();
	           
	            switch(type) {
	            
	            case 1 :
	                 sendMsg();
	                 break;
	                 
	             case 2 :       
	            	 
	                 break;
	                 
	             }
	            
	            Menu.showmenu3();
	            break;
	            
	      }
	       
	}
	//---------------------------------------------------------------------------------------->
    //원하는 도서가 있을 경우 구매 요청 메시지 전송 기능
	public void sendMsg() {
		
		System.out.print(">> 구매를 원하시는 책 번호를 입력해주세요. : ");
		scan.nextLine();
		String bookId = scan.nextLine();
		
		System.out.print(">> 판매자에게 보낼 메세지를 입력해주세요. : ");
		String msg = scan.nextLine();
		
		MSG_VO msgvo = new MSG_VO(print.myid, bookId, msg);
		message.sendMsg(msgvo);
		
	}
	
	}

