package kr.co.bitcamp.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.util.JDBC_Close;

public class Board_DAO {
	   
	   private final String DRIVER = "oracle.jdbc.OracleDriver"; 
	   private final String URL = "jdbc:oracle:thin:@localhost:1521:xe"; 
	   private final String USER = "mystudy";
	   private final String PASSWORD = "mystudypw"; 
	   
	   private Connection conn;   
	   private PreparedStatement prestmt;
	   private ResultSet rs;
	   
	   public Board_DAO() {
	      try {
	         Class.forName(DRIVER);
	      } catch (ClassNotFoundException e) {
	         e.printStackTrace();
	      }
	   }
	   
	   //---------------------------------------------------------------------------------------->
       //게시판 등록
	   public int community(Board_VO board) {
	        int result = 0;
	        
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        
	        try {
	           conn = DriverManager.getConnection(URL, USER, PASSWORD);

	           StringBuilder sb = new StringBuilder();
	           
	           sb.append("INSERT INTO BOOK_COMMUNITY ");
	           sb.append("		 (NO, ID, CATEGORY, TITLE, CONTENT, REDATE) ");
	           sb.append("VALUES (SEQ_BOOK_COMMUNITY.NEXTVAL, ?, ?, ?, ?, SYSDATE) ");
	          
	           pstmt = conn.prepareStatement(sb.toString());
	           
	           pstmt.setString(1, board.getId());
	           pstmt.setString(2, board.getCategory());
	           pstmt.setString(3, board.getTitle());
	           pstmt.setString(4, board.getContent());
	
	               
	           result = pstmt.executeUpdate();
	           
	         } catch (SQLException e) {
	        	 
	            e.printStackTrace();
	            
	         } finally {
	        	 
	            JDBC_Close.closeConnPrestmt(conn, pstmt);
	            
	         }
	        
	        return result;
	     }	   
	   
	   //---------------------------------------------------------------------------------------->
       //게시판 목록
	   public List<Board_VO> listAll() {
		      List<Board_VO> listAll = null;
		      
		      try {
		         conn = DriverManager.getConnection(URL, USER, PASSWORD);

		         StringBuilder sb = new StringBuilder();
		         String str = "관리자";
		         
		         sb.append("SELECT * ");
		         sb.append("  FROM BOOK_COMMUNITY ");
		         sb.append(" ORDER BY DECODE(ID, '관리자',1), ");
		         sb.append("	 	  		 TO_NUMBER(NO), REDATE 	 ");
		         
		         prestmt = conn.prepareStatement(sb.toString());
		         
		         rs = prestmt.executeQuery();
		         
		         listAll = new ArrayList<Board_VO>();
		         
		         while (rs.next()) {
		        	 listAll.add(new Board_VO(
		                  rs.getString("NO"),
		                  rs.getString("ID"),
		                  rs.getString("CATEGORY"),
		                  rs.getString("TITLE"),
		                  rs.getString("CONTENT"),
		                  rs.getString("REDATE") ) );
		         }
		         
		      } catch (SQLException e) {
		    	  
		         e.printStackTrace();
		         
		      } finally {
		    	  
		         JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
		         
		      }
		      
		      return listAll;
		   }
	   
	
}
