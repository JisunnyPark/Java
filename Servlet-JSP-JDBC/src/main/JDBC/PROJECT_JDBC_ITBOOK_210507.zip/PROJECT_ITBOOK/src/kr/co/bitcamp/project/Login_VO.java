package kr.co.bitcamp.project;

public class Login_VO {

    private String id;
    private String Pw;
    private String Name;
    private String phone;
    private String address;
    
    
    public Login_VO(String id, String pw, String name, String phone, String address) {
        super();
        this.id = id;
        Pw = pw;
        Name = name;
        this.phone = phone;
        this.address = address;
    }
    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPw() {
        return Pw;
    }

    public void setPw(String pw) {
        Pw = pw;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


    @Override
    public String toString() {
        return "Login_VO [id=" + id + ", Pw=" + Pw + ", Name=" + Name + ", phone=" + phone + ", address=" + address
                + "]";
    }
    
    
    
}
