package kr.co.bitcamp.project;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Iterator;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Login_Print {
    Login_DAO Ldao;
    static String myid;
    
    public Login_Print() {
        Ldao = new Login_DAO();
    }
    
    //---------------------------------------------------------------------------------------->
    //회원가입
    
    public void CreateMembers(){        
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println(">>> 회원가입을 시작합니다.");
        System.out.println("");
        System.out.print("ID : ");
        String id = scanner.nextLine();
        System.out.print("PassWord : ");
        String password = scanner.nextLine();
        System.out.print("Name : ");
        String name = scanner.nextLine();
        System.out.print("PhoneNumber : ");
        String phone = scanner.nextLine();
        System.out.print("Address : ");
        String address = scanner.nextLine();  
       
        Login_VO vo = new Login_VO(id, password, name, phone, address);
        Ldao.insertCreateMember(vo); 
        
        System.out.println("");
        System.out.println("✔　" +"["+  id + "]님의 회원가입이 정상적으로 완료되었습니다!\n");
    }

    //---------------------------------------------------------------------------------------->
    //로그인
    public void LoginMembers() {
        
        

        while(true) {
            
            Menu menu2 = new Menu();
            Scanner scanner = new Scanner(System.in);
            Login_DAO dao = new Login_DAO();
            System.out.println("");
            System.out.print("ID : ");
            String id = scanner.nextLine();
            System.out.print("PassWord : ");
            String password = scanner.nextLine();
            
            int result = dao.loginTest(id, password);
           
            if(result == 1){
                System.out.println("");
                System.out.println("✔　" +"["+  id + "]님 환영합니다!");
                myid = id;
                Menu.showMenu();
            }
            
            else if(result == 0) {
                System.out.println("※ 비밀번호가 일치하지 않습니다. 다시 입력해주세요");
            }
            else if( result == -1) {
                System.out.println("※ 아이디가 존재하지않습니다. 다시 입력해주세요");
            }

        }
        
    }
   
}
