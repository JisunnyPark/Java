package kr.co.bitcamp.project;

import java.sql.Date;

public class List_VO {
	private String custId;
	private String bookId;
	private String category;
	private String bookName;
	private String price;
	private String description;
	private String location;
	private Date redate;		
	
	public List_VO(String custId, String bookId, String category, String bookName, String price,
			String description, String location, Date redate) {
		super();
		this.custId = custId;
		this.bookId = bookId;
		this.category = category;
		this.bookName = bookName;
		this.price = price;
		this.description = description;
		this.location = location;
		this.redate = redate;
	}

	public List_VO(String custId) {
		super();
		this.custId = custId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustID(String custId) {
		this.custId = custId;
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public Date getRedate() {
		return redate;
	}

	public void setRedate(Date redate) {
		this.redate = redate;
	}
	
	@Override
	public String toString() {
		return  " ID: " + custId
		        + "\n 책 번호: " + bookId
		        + "\n 카테고리: "+ category
		        + "\n 책이름: " + bookName
		        + "\n 가격: " + price
		        + "\n 설명: " + description
		        + "\n 지역: " + location
				+ "\n 날짜: "+ redate +  "\n" ;
	}
	

	
	
	

}
