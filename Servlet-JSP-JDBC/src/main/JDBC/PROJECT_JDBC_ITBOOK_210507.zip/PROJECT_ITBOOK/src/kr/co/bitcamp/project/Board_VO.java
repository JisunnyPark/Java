package kr.co.bitcamp.project;

public class Board_VO {

	private String no;
	private String id;
	private String category;
	private String title;
	private String content;
	private String redate;
	
	public Board_VO(String no, String id, String category, String title, String content, String redate) {
		super();
		this.no = no;
		this.id = id;
		this.category = category;
		this.title = title;
		this.content = content;
		this.redate = redate;
	}

	public Board_VO(String id, String category, String title, String content) {
		super();
		this.id = id;
		this.category = category;
		this.title = title;
		this.content = content;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRedate() {
		return redate;
	}

	public void setRedate(String redate) {
		this.redate = redate;
	}

	@Override
	public String toString() {
		return 	  "\n ☑ 글 번호 : " + no 
				+ "\n ·  작성자 아이디 : " + id 
				+ "\n ·  카테고리 : " + category
				+ "\n ·  작성일 : " + redate
				+ "\n" 
				+ "\n ·  제목 : " + title 
				+ "\n ·  내용 : " + content;
	}
	
	
}
