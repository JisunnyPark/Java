package kr.co.bitcamp.project;

   import java.sql.Connection;
   import java.sql.Date;
   import java.sql.DriverManager;
   import java.sql.PreparedStatement;
   import java.sql.ResultSet;
   import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
   import java.util.List;
   import java.util.Scanner;
   import common.util.JDBC_Close;

   public class Manage_DAO {
   
      private final String DRIVER = "oracle.jdbc.OracleDriver"; 
      private final String URL = "jdbc:oracle:thin:@localhost:1521:xe"; 
      private final String USER = "mystudy";
      private final String PASSWORD = "mystudypw"; 
      
      Login_Print lp = new Login_Print();
      
      private Connection conn;  
      private PreparedStatement prestmt;
      private ResultSet rs;
      
      public Manage_DAO() {
         
         try {
            
            Class.forName(DRIVER);
            
         } catch (ClassNotFoundException e) {
            
            e.printStackTrace();
            
         }
         
      }
      
      //---------------------------------------------------------------------------------------->
      //판매도서 등록
      public int uploadBook(Manage_VO upload) {
           int result = 0;
           
           Connection conn = null;
           PreparedStatement pstmt = null;
           
           try {
              conn = DriverManager.getConnection(URL, USER, PASSWORD);

              StringBuilder sb = new StringBuilder();
              
              sb.append("INSERT INTO BOOK_MANAGEMENT ");
              sb.append("       (CUSTID, BOOKID, CATEGORY, BOOKNAME, PRICE, DESCRIPTION, LOCATION, REDATE) ");
              sb.append("VALUES (?, SEQ_BOOK_MANAGEMENT.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE) ");
             
              pstmt = conn.prepareStatement(sb.toString());
              
              pstmt.setString(1, upload.getCustId());
              pstmt.setString(2, upload.getCategory());
              pstmt.setString(3, upload.getBookName());
              pstmt.setString(4, upload.getPrice());
              pstmt.setString(5, upload.getDescription());
              pstmt.setString(6, upload.getLocation());
                  
              result = pstmt.executeUpdate();
              
            } catch (SQLException e) {
               
               e.printStackTrace();
               
            } finally {
               
               JDBC_Close.closeConnPrestmt(conn, pstmt);
               
            }
           
           return result;
           
        }
      
      //---------------------------------------------------------------------------------------->
      //나의 도서 관리 (등록한 도서 정보 수정을 위한 나의 등록 도서 목록 기능)
      
      public List<List_VO> myList() {
            List<List_VO> myList = null;
            
            String id = lp.myid; 
            
            try {
               conn = DriverManager.getConnection(URL, USER, PASSWORD);
               
               StringBuilder sb = new StringBuilder();
               
               sb.append("SELECT * ");
               sb.append("  FROM BOOK_MANAGEMENT ");
               sb.append(" WHERE CUSTID = " + "'" + id + "'");
               sb.append(" ORDER BY BOOKID ");
               
               prestmt = conn.prepareStatement(sb.toString());          
               
               rs = prestmt.executeQuery();
               
               myList = new ArrayList<List_VO>();
               while (rs.next()) {

                  myList.add(new List_VO(
                        rs.getString("CUSTID"),
                        rs.getString("BOOKID"),
                        rs.getString("CATEGORY"),
                        rs.getString("BOOKNAME"),
                        rs.getString("PRICE"),
                        rs.getString("DESCRIPTION"),
                        rs.getString("LOCATION"),
                        rs.getDate("REDATE")) );
               }
            } catch (SQLException e) {
                           
               e.printStackTrace();
               
            } finally {
               
               JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
               
            }
            
            return myList;
         }
         

      //---------------------------------------------------------------------------------------->
      //도서 정보 수정
      public int modifyBook(Manage_VO modify) {
         int result = 0;
         
         try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

            StringBuilder sb = new StringBuilder();
            
            sb.append("UPDATE Book_MANAGEMENT ");
            sb.append("   SET CATEGORY = ?, ");    
            sb.append("       BOOKNAME = ?, ");    
            sb.append("       PRICE = ?, "); 
            sb.append("       DESCRIPTION = ?, ");  
            sb.append("       LOCATION = ? ");  
            sb.append(" WHERE BOOKID = ? AND CUSTID = ? "); 
   
            prestmt = conn.prepareStatement(sb.toString());

            int i = 1;
            prestmt.setString(i++, modify.getCategory());
            prestmt.setString(i++, modify.getBookName());
            prestmt.setString(i++, modify.getPrice());
            prestmt.setString(i++, modify.getDescription());
            prestmt.setString(i++, modify.getLocation());
            prestmt.setString(i++, modify.getBookId());
            prestmt.setString(i++, modify.getCustId());
            
            result = prestmt.executeUpdate();
            
         } catch (SQLException e) {
            
            e.printStackTrace();
            
         } finally {
            
            JDBC_Close.closeConnPrestmt(conn, prestmt);
            
         }
         
         return result;
      }   
      
      //---------------------------------------------------------------------------------------->
      //도서 삭제
      public int deleteBook(Manage_VO delete) {
         int result = 0;
         try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            
            StringBuilder sb = new StringBuilder();
            
            sb.append("DELETE FROM BOOK_MANAGEMENT WHERE BOOKID = ?");
            
            prestmt = conn.prepareStatement(sb.toString());
            prestmt.setString(1, delete.getBookId());
            result = prestmt.executeUpdate();
            
         } catch (SQLException e) {
            
            e.printStackTrace();
            
         } finally {
            
            JDBC_Close.closeConnPrestmt(conn, prestmt);
            
         }
         
         return result;
         
      }    
      
      //---------------------------------------------------------------------------------------->
      //쪽지함 확인
      public void checkMsg() {
         
         String result = null;
         String id = lp.myid; 
         
         try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);            
            
            Statement stmt = conn.createStatement();
                    
            String sql = "SELECT M.BOOKID, M.CATEGORY, M.BOOKNAME, M.PRICE, " +
                      "M.DESCRIPTION, M.LOCATION, M.REDATE, " +
                      "M2.REQUESTID, M2.MESSAGE, M2.REDATE " +
                      "   FROM BOOK_MANAGEMENT M, BOOK_MESSANGER M2 " +
                      "WHERE M.BOOKID = M2.BOOKID " +
                      "AND M.CUSTID = " + "'" + id + "'" +
                      " AND M2.MESSAGE IS NOT NULL ";
            
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
            
               String a = rs.getString(1);   
               String b = rs.getString(2);   
               String c = rs.getString(3);
               String d = rs.getString(4);
               String e = rs.getString(5);
               String f = rs.getString(6);
               String g = rs.getString(7) ;      
               String h = rs.getString(8);
               String i = rs.getString(9);
               String j = rs.getString(10);
               
               	  System.out.println("");
                  System.out.println(" ·책 번호 : " + a
                                    + "\n ·책 카테고리 : "+ b
                                    + "\n ·책 제목 : " + c
                                    + "\n ·가격 : " + d
                                    + "\n ·도서 설명 : " + e
                                    + "\n ·거래 지역 : " + f
                                    + "\n ·등록일 : " + g
                                    + "\n"
                                    + "\n ☑ 구매 희망자 아이디 : " + h
                                    + "\n ☑ 메세지 내용 : " + i
                                    + "\n ☑ 메세지 전송 날짜 : " + j);
            }
            
         } catch (SQLException e) {
            
            e.printStackTrace();
            
         } finally {
            
            JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
            
         }   
         
      }   
   }
      
      
   

   
