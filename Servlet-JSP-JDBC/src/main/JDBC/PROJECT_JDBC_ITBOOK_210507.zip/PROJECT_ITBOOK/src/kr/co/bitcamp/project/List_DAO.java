package kr.co.bitcamp.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.util.JDBC_Close;

public class List_DAO {
	
	   private final String DRIVER = "oracle.jdbc.OracleDriver"; 
	   private final String URL = "jdbc:oracle:thin:@localhost:1521:xe"; 
	   private final String USER = "mystudy";
	   private final String PASSWORD = "mystudypw"; 
	   
	   private Connection conn; 
	   private PreparedStatement prestmt;
	   private ResultSet rs;
	   
	   public List_DAO() {
		   
	      try {
	    	  
	         Class.forName(DRIVER);
	         
	      } catch (ClassNotFoundException e) {
	    	  
	         e.printStackTrace();
	         
	      } 
	      
	      }
	   
	   //---------------------------------------------------------------------------------------->
       //전체 도서 목록
	   public List<List_VO> listAll() {
		      List<List_VO> listall = null;
		      
		      try {

		         conn = DriverManager.getConnection(URL, USER, PASSWORD);

		         StringBuilder sb = new StringBuilder();
		         
		         sb.append("SELECT * ");
		         sb.append("  FROM BOOK_MANAGEMENT ");
		         sb.append(" ORDER BY TO_NUMBER(BOOKID) ");
		         
		         prestmt = conn.prepareStatement(sb.toString());
		         
		         rs = prestmt.executeQuery();
		         
		         listall = new ArrayList<List_VO>();
		         
		         while (rs.next()) {

		        	 listall.add(new List_VO(
		                  rs.getString("CUSTID"),
		                  rs.getString("BOOKID"),
		                  rs.getString("CATEGORY"),
		                  rs.getString("BOOKNAME"),
		                  rs.getString("PRICE"),
		                  rs.getString("DESCRIPTION"),
		                  rs.getString("LOCATION"),
		                  rs.getDate("REDATE") ) );
		        	 
		         }
		         
		      } catch (SQLException e) {
		    	  
		         e.printStackTrace();
		         
		      } finally {
		    	  
		         JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
		         
		      }
		      
		      return listall;
		   }

	
	   //---------------------------------------------------------------------------------------->
       //카테고리별 목록 (프로그래밍)
	   public List<List_VO> lstProgram() {
		      List<List_VO> lstProgram = null;
		      
		      try {
		         conn = DriverManager.getConnection(URL, USER, PASSWORD);
		         
		         StringBuilder sb = new StringBuilder();
		         String str = "프로그래밍";
		         sb.append("SELECT * ");
		         sb.append("  FROM BOOK_MANAGEMENT ");
		         sb.append(" WHERE CATEGORY = '" + str + "' ");
		         sb.append(" ORDER BY TO_NUMBER(BOOKID) ");
		         prestmt = conn.prepareStatement(sb.toString());
		         
		         rs = prestmt.executeQuery();
		         
		         lstProgram = new ArrayList<List_VO>();
		         while (rs.next()) {

		        	 lstProgram.add(new List_VO(
		                  rs.getString("CUSTID"),
		                  rs.getString("BOOKID"),
		                  rs.getString("CATEGORY"),
		                  rs.getString("BOOKNAME"),
		                  rs.getString("PRICE"),
		                  rs.getString("DESCRIPTION"),
		                  rs.getString("LOCATION"),
		                  rs.getDate("REDATE")) );
		         }
		      } catch (SQLException e) {
		    	  
		         e.printStackTrace();
		         
		      } finally {
		    	  
		         JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
		         
		      }
		      
		      return lstProgram;
		   }
	   
	   //---------------------------------------------------------------------------------------->
       //카테고리별 목록 (데이터베이스)
	   public List<List_VO> lstDB() {
		      List<List_VO> lstDB = null;
		      
		      try {
		         conn = DriverManager.getConnection(URL, USER, PASSWORD);

		         StringBuilder sb = new StringBuilder();
		         String str = "데이터베이스";
		         
		         sb.append("SELECT * ");
		         sb.append("  FROM BOOK_MANAGEMENT ");
		         sb.append(" WHERE CATEGORY = '" + str + "' ");
		         sb.append(" ORDER BY TO_NUMBER(BOOKID) ");
		         
		         prestmt = conn.prepareStatement(sb.toString());
		         
		         rs = prestmt.executeQuery();
		         
		         lstDB = new ArrayList<List_VO>();
		         while (rs.next()) {

		        	 lstDB.add(new List_VO(
		                  rs.getString("CUSTID"),
		                  rs.getString("BOOKID"),
		                  rs.getString("CATEGORY"),
		                  rs.getString("BOOKNAME"),
		                  rs.getString("PRICE"),
		                  rs.getString("DESCRIPTION"),
		                  rs.getString("LOCATION"),
		                  rs.getDate("REDATE")) );
		         }
		      } catch (SQLException e) {
		    	  
		         e.printStackTrace();
		         
		      } finally {
		    	  
		         JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
		         
		      }
		      
		      return lstDB;
		      
		   }
	   
	   //---------------------------------------------------------------------------------------->
       //카테고리별 목록 (수험서)	   
	   public List<List_VO> lstCerti() {
		      List<List_VO> lstCerti = null;
		      
		      try {
		         conn = DriverManager.getConnection(URL, USER, PASSWORD);
		         
		         StringBuilder sb = new StringBuilder();
		         String str = "수험서";
		         
		         sb.append("SELECT * ");
		         sb.append("  FROM BOOK_MANAGEMENT ");
		         sb.append(" WHERE CATEGORY = '" + str + "' ");
		         sb.append(" ORDER BY TO_NUMBER(BOOKID) ");
		         
		         prestmt = conn.prepareStatement(sb.toString());
		         
		         rs = prestmt.executeQuery();
		         
		         lstCerti = new ArrayList<List_VO>();
		         while (rs.next()) {

		        	 lstCerti.add(new List_VO(
		                  rs.getString("CUSTID"),
		                  rs.getString("BOOKID"),
		                  rs.getString("CATEGORY"),
		                  rs.getString("BOOKNAME"),
		                  rs.getString("PRICE"),
		                  rs.getString("DESCRIPTION"),
		                  rs.getString("LOCATION"),
		                  rs.getDate("REDATE")) );
		         }
		         
		      } catch (SQLException e) {
		    	  
		         e.printStackTrace();
		         
		      } finally {
		    	  
		         JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
		         
		      }
		      
		      return lstCerti;
		   }
	   
	   //---------------------------------------------------------------------------------------->
       //카테고리별 목록 (기타)	   
	   public List<List_VO> lstEtc() {
		      List<List_VO> lstEtc = null;
		      
		      try {
		         conn = DriverManager.getConnection(URL, USER, PASSWORD);
		         
		         StringBuilder sb = new StringBuilder();
		         String str = "기타";
		         
		         sb.append("SELECT * ");
		         sb.append("  FROM BOOK_MANAGEMENT ");
		         sb.append(" WHERE CATEGORY = '" + str + "' ");
		         sb.append(" ORDER BY TO_NUMBER(BOOKID) ");
		         
		         prestmt = conn.prepareStatement(sb.toString());
		         
		         rs = prestmt.executeQuery();
		         
		         lstEtc = new ArrayList<List_VO>();
		         while (rs.next()) {

		        	 lstEtc.add(new List_VO(
		                  rs.getString("CUSTID"),
		                  rs.getString("BOOKID"),
		                  rs.getString("CATEGORY"),
		                  rs.getString("BOOKNAME"),
		                  rs.getString("PRICE"),
		                  rs.getString("DESCRIPTION"),
		                  rs.getString("LOCATION"),
		                  rs.getDate("REDATE")) );
		         }
		         
		      } catch (SQLException e) {
		    	  
		         e.printStackTrace();
		         
		      } finally {
		    	  
		         JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
		         
		      }
		      
		      return lstEtc;
		   }
	   
	   //---------------------------------------------------------------------------------------->
       //전체 목록에서 도서 검색
	      
	   public List<List_VO> search() {
		      List<List_VO> search = null;
		      
		      try {
		         conn = DriverManager.getConnection(URL, USER, PASSWORD);
		         
		         StringBuilder sb = new StringBuilder();
		         List_Print lp = new List_Print();
		         
		         String str = lp.bookName;
		         
		         sb.append("SELECT * ");
		         sb.append("  FROM BOOK_MANAGEMENT ");
		         sb.append(" WHERE BOOKNAME like '%" + str + "%' ");
		         sb.append(" ORDER BY TO_NUMBER(BOOKID) ");
		         
		         prestmt = conn.prepareStatement(sb.toString());
		         
		         rs = prestmt.executeQuery();
		         
		         search = new ArrayList<List_VO>();
		         while (rs.next()) {

		        	 search.add(new List_VO(
		                  rs.getString("CUSTID"),
		                  rs.getString("BOOKID"),
		                  rs.getString("CATEGORY"),
		                  rs.getString("BOOKNAME"),
		                  rs.getString("PRICE"),
		                  rs.getString("DESCRIPTION"),
		                  rs.getString("LOCATION"),
		                  rs.getDate("REDATE")) );
		         }
		         
		      } catch (SQLException e) {
		    	  
		         e.printStackTrace();
		         
		      } finally {
		    	  
		         JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
		         
		      }
		      
		      return search;
		   }
	   
	   public List_VO searchBook(List2_VO vo) {
		   List_VO mvo = null;
			
			try { 
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
				
				StringBuilder sb = new StringBuilder();
				
				sb.append("SELECT * ");
				sb.append("	FROM BOOK_MANAGEMENT ");
				sb.append("WHERE BOOKNAME LIKE ? ");
				sb.append(" ORDER BY TO_NUMBER(BOOKID) ");
			
				prestmt = conn.prepareStatement(sb.toString());

				prestmt.setString(1, vo.getBookName());	
				
				rs = prestmt.executeQuery();

				if (rs.next()) {
					mvo = new List_VO(
							rs.getString("CUSTID"),	
							rs.getString("BOOKID"),	
							rs.getString("CATEGORY"),
							rs.getString("BOOKNAME"),
							rs.getString("PRICE"),
							rs.getString("DESCRIPTION"),
							rs.getString("LOCATION"),
							rs.getDate("REDATE") ) ;			
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
				
			} finally {
				
				JDBC_Close.closeConnPrestmtRs(conn, prestmt, rs);
				
			}	
			
			return mvo;
		}	
	   
	   //---------------------------------------------------------------------------------------->
       //구매를 원하는 도서가 있을 경우, 메세지 전송
	   public int sendMsg(MSG_VO message) {
	        int result = 0;
	        
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        
	        try {
	           conn = DriverManager.getConnection(URL, USER, PASSWORD);

	           StringBuilder sb = new StringBuilder();
	           
	           sb.append("INSERT INTO BOOK_MESSANGER ");
	           sb.append("		 (REQUESTID, BOOKID, MESSAGE, REDATE) ");
	           sb.append("VALUES (?, ?, ?, SYSDATE) ");
	           
	           pstmt = conn.prepareStatement(sb.toString());
	           
	           pstmt.setString(1, message.getRequestId());
	           pstmt.setString(2, message.getBookId());
	           pstmt.setString(3, message.getContent());
	
	               
	           result = pstmt.executeUpdate();
	           
	         } catch (SQLException e) {
	        	 
	            e.printStackTrace();
	            
	         } finally {
	        	 
	            JDBC_Close.closeConnPrestmt(conn, pstmt);
	            
	         }
	        
	        return result;
	     }
	   
}
