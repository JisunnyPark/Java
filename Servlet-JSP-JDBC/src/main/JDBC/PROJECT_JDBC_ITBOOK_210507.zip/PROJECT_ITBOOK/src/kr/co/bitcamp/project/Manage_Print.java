package kr.co.bitcamp.project;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Manage_Print {
   
   static Scanner scan = new Scanner(System.in);
    Manage_DAO dao = new Manage_DAO();
    Login_Print print = new Login_Print();    
    
   Manage_DAO upload;
   Manage_DAO mylst;
   Manage_DAO modify;
   Manage_DAO delete;
   Manage_DAO select;
   Manage_DAO message;
   Manage_DAO msg;
   
    public Manage_Print() {
      upload = new Manage_DAO();
      mylst = new Manage_DAO();
      modify = new Manage_DAO();
      delete = new Manage_DAO();
      select = new Manage_DAO();
      message = new Manage_DAO();
      msg = new Manage_DAO();
   }
    
   // -----------------------------------------------------------------------------
   // 판매도서 등록
   public void uploadBook() {

       String category = "";
       String location = "";
       boolean inputSwitch = true;

       System.out.println("");
       System.out.println("※ 카테고리를 [ 프로그래밍 | 데이터베이스 | 수험서 | 기타 ] 중에서 하나만 입력해주세요.");
       System.out.print("카테고리 : ");
       String category2 = scan.nextLine();
            
       while(inputSwitch) {
          
       switch (category2) {
       
       case "프로그래밍" : category = category2;
          inputSwitch = false;
          break;
          
       case "데이터베이스" : category = category2;
          inputSwitch = false;
          break;
          
       case "수험서" : category = category2;
          inputSwitch = false;
          break;
       
       case "기타" : category = category2;
          inputSwitch = false;
          break;
              
       default :
           System.out.println("※ 카테고리를 다시 입력해주세요! ");
             System.out.print("카테고리 : ");
             category2 = scan.nextLine();
       }
            
     }

        System.out.print("도서명 : ");  
        String name = scan.nextLine();
        
        System.out.print("가격 : ");  
        String price = scan.nextLine();
        
        System.out.print("도서 설명 : ");
        String content = scan.nextLine();
        
        inputSwitch = true;
        
        System.out.println("※ [ 서울 | 경기 | 인천 | 기타 ] 중에서 입력해주세요.");
        System.out.print("지역 : ");
        String location2 = scan.nextLine();
        
        while(inputSwitch) {
           
        switch (location2) {
        
        case "서울" : location = location2;
           inputSwitch = false;
           break;
           
        case "경기" : location = location2;
           inputSwitch = false;
           break;
           
        case "인천" : location = location2;
           inputSwitch = false;
           break;
        
        case "기타" : location = location2;
           inputSwitch = false;
           break;
               
        default :
            System.out.println("※ 지역을 다시 입력해주세요! ");
            System.out.print("지역 : ");
            location2 = scan.nextLine();
        }
             
      }
        Manage_VO vo = new Manage_VO(print.myid, category, name, price, content, location);
        upload.uploadBook(vo);
        Menu.showMenu();
       
}
       
   // -----------------------------------------------------------------------------
   // 나의 도서 관리
   public void manageBook() {
      
      System.out.println("");
      System.out.println(" ========== [ 나의 도서 목록 ] ==========");
      System.out.println("");
      List<List_VO> lvo = mylst.myList();
      
        for (List_VO mvo : lvo) {
            System.out.println(mvo);
        }
   }
   
   // -----------------------------------------------------------------------------
   // 등록한 도서정보 수정
   public void modifyBook() {   
	   
      String category = "";
      String location = "";
      boolean inputSwitch = true;
      
      System.out.println("");
      System.out.println(" ========== [ 나의 도서 목록 ] ==========");
      List<List_VO> lvo = mylst.myList();
      
        for (List_VO mvo : lvo) {
            System.out.println(mvo);
        }
       
      System.out.println(">> 수정을 원하는 책 번호를 입력해주세요.");
      System.out.print("책 번호 : ");
      String bno = scan.nextLine();
      
      System.out.println("[ 프로그래밍 | 데이터베이스 | 수험서 | 기타 ] 중에서 하나만 입력해주세요.");
      System.out.print("카테고리 : ");
      String category3 = scan.nextLine();
      
      while(inputSwitch) {
          
      switch (category3) {
      
      case "프로그래밍" : category = category3;
         inputSwitch = false;
         break;
         
      case "데이터베이스" : category = category3;
         inputSwitch = false;
         break;
         
      case "수험서" : category = category3;
         inputSwitch = false;
         break;
      
      case "기타" : category = category3;
         inputSwitch = false;
         break;
             
      default :
          System.out.println("※ 카테고리를 다시 입력해주세요! ");
            System.out.print("카테고리 : ");
            category3 = scan.nextLine();
      }
           
    }
      
        System.out.print("도서명 : ");  
        String name = scan.nextLine();
        
        System.out.print("가격 : ");  
        String price = scan.nextLine();
        
        System.out.print("도서 설명 : ");
        String content = scan.nextLine();
        
        inputSwitch = true;
        
        System.out.println("※ [ 서울 | 경기 | 인천 | 기타 ] 중에서 입력해주세요.");
        System.out.print("지역 : ");
        String location3 = scan.nextLine();
        
        while(inputSwitch) {
            
            switch (location3) {
            
            case "서울" : location = location3;
               inputSwitch = false;
               break;
               
            case "경기" : location = location3;
               inputSwitch = false;
               break;
               
            case "인천" : location = location3;
               inputSwitch = false;
               break;
            
            case "기타" : location = location3;
               inputSwitch = false;
               break;
                   
            default :
                System.out.println("※ 지역을 다시 입력해주세요! ");
                  System.out.print("지역 : ");
                  location3 = scan.nextLine();
            }
                 
          }
      
        Manage_VO vo2 = new Manage_VO(print.myid, bno, category, name, price, content, location);
        modify.modifyBook(vo2);
        
        System.out.println("");
        System.out.println(" ========== [ 수정 후 나의 도서목록 ] ==========");
        List<List_VO> lvo2 = mylst.myList();
        for (List_VO mvo : lvo2) {
           
            System.out.println(mvo);
            
        }
       
   }
   
   // -----------------------------------------------------------------------------
   // 등록한 도서정보 삭제
   public void deleteBook() {
       System.out.println("");
       System.out.println(" ========== [ 나의 도서 목록 ] ==========");
       List<List_VO> lvo = mylst.myList();
      
        for (List_VO mvo : lvo) {
            System.out.println(mvo);
        }
       
      System.out.println(">> 삭제를 원하는 책 번호를 입력해주세요.");
      System.out.print("책 번호 : ");
      String bno = scan.nextLine();
      Manage_VO vo2 = new Manage_VO(bno);
      delete.deleteBook(vo2);
   
   }
   
   // -----------------------------------------------------------------------------
   // 쪽지함 확인
   public void checkMsg() {
      
      msg.checkMsg();
      
   }
   
   
}