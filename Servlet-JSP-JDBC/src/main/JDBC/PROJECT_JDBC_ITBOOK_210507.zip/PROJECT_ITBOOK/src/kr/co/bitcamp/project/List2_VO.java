package kr.co.bitcamp.project;

public class List2_VO {

	private String bookName;

	public List2_VO(String bookName) {
		super();
		this.bookName = bookName;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
}
