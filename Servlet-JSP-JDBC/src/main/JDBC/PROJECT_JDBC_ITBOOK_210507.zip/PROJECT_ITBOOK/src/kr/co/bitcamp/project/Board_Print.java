package kr.co.bitcamp.project;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Board_Print {
	
	static Scanner scan = new Scanner(System.in);
    Menu bm2 = new Menu();
    Manage_DAO dao = new Manage_DAO();
    Login_Print print = new Login_Print();
    
    Board_DAO board;
    
    public Board_Print() {
		board = new Board_DAO();
	}
	
    //---------------------------------------------------------------------------------------->
    //게시글 업로드
	public void uploadPost() {
		String id = print.myid;
		String category = "";
		boolean inputSwitch = true;
		 
		System.out.println("");
		System.out.println(" ※ [ 자유이야기 | 스터디 | 구인구직 | 기타 ] 중에서 하나만 입력해주세요.");
		System.out.print("카테고리 : ");
		String category1 = scan.nextLine();

		   inputSwitch = true;
		   
	       while(inputSwitch) {
	          
	       switch (category1) {
	       
	       case "자유이야기" : category = category1;
	          inputSwitch = false;
	          break;
	          
	       case "스터디" : category = category1;
	          inputSwitch = false;
	          break;
	          
	       case "구인구직" : category = category1;
	          inputSwitch = false;
	          break;
	       
	       case "기타" : category = category1;
	          inputSwitch = false;
	          break;
	          
	       case "공지사항" : 
	    	   if(print.myid.equals("관리자")) {
	    		   category = category1;
	    		   inputSwitch = false;
	    		   break;
	    	   }
	              
	       default :
	           System.out.println("");
	           System.out.println("※ 카테고리를 다시 입력해주세요! ");
	             System.out.print("카테고리 : ");
	             category1 = scan.nextLine();
	       }
	            
	     }
		System.out.println("");
		System.out.print("제목: ");
		String title = scan.nextLine();
		
		System.out.print("내용: ");
		String content = scan.nextLine();
		
		Board_VO vo = new Board_VO(id, category, title, content);
		board.community(vo);
		
	    bm2.showMenu();
	}

	
	//---------------------------------------------------------------------------------------->
    //게시판 리스트
	public void boardList() {
		
	    System.out.println(" ========== [ 커뮤니티 게시판 ] ==========");
		  
	        List<Board_VO> boardLst = board.listAll();
	        
	        for (Board_VO bvo : boardLst) {
	        	
	            System.out.println(bvo);
	            
	        }
	        
	        bm2.showMenu();
	        
	}
}
